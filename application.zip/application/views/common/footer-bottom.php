 <!-- Footer Start -->
 <div class="container-fluid pt-4 px-4">
     <div class="bg-secondary rounded-top px-4 py-3">
         <div class="row align-items-center justify-content-between text-center" style="font-size:12px;">
             <div class="col-md-6 col-sm-12 text-md-start">
                 &copy; <a href="#">Get Blood</a> <span><?php echo date("Y"); ?></span>, All Right Reserved.
             </div>
             <div class="col-md-6 col-sm-12 text-md-end">
                 Developed By <span class="fw-bold">Abir Hossain</span><br><span>abir.work2002@gmail.com</span>
             </div>
         </div>
     </div>
 </div>
 <!-- Footer End -->